insert into Producto (id,nombre,descripcion,precio) values (1,'El Ingenioso Hidalgo Don Quijote de la Mancha','Clásico de la literatura española',32);
insert into Producto (id,nombre,descripcion,precio) values (2,'The definitive guide to JSF in Java EE 8','The definitive guide to JSF in Java EE 8',42);
insert into Producto (id,nombre,descripcion,precio) values (3,'Naruto 1','Season 1',10);
insert into Producto (id,nombre,descripcion,precio) values (4,'Naruto 2','Season 1',10);