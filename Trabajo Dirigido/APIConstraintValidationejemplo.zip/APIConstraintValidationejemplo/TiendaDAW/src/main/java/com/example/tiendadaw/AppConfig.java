package com.example.tiendadaw;

import jakarta.faces.annotation.FacesConfig;

@FacesConfig
public class AppConfig {
}
