Todos los formularios son preecarcados con información válida. Para comprobar la validación implementada basta con rellenar estos campos de forma inválida. 
Restricciones implementadas:
	- Usuario:
		- Email obligatorio.
		- Restricción de formato de email.
		- Contraseña obligatoria.
		- Restricción de formato de tarjeta (número de entre 10 a 12 carácteres).
	- Producto:
		- Nombre obligatorio.
		- Restricción de longitud mínima de 10 carácteres para el nombre.
		- Precio obligatorio.
		- Restricción de precio mínimo de 1.
		- Stock obligatoro.
		- Restrición de stock mínimo de 1.
	- Compra:
		- Id obligatorio.
		- Restriccón de id mínimo de 1
		- IdCompra obligatorio.
		- Restriccón de idCompra mínimo de 1
		- email obligatorio.
		- Restricción de formato de email.
	